from django.shortcuts import render
from datetime import datetime
import requests

# def index(request):
#     return render(request, "index.html", context={'prenom': 'patrick', 'date': datetime.today()})
#

